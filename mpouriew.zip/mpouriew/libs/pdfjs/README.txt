mpouriew — PDF.js setup
========================

This folder must contain two files before PDF preview will work:

  libs/pdfjs/pdf.min.js
  libs/pdfjs/pdf.worker.min.js

These are Mozilla's PDF.js library files. They are NOT bundled in this
package (they are fetched from an external source and are too large to
ship as generated text), but you can add them in under a minute using
ONE of the options below.

--------------------------------------------------------------------
OPTION A — Automatic (recommended, Windows PowerShell)
--------------------------------------------------------------------
1. Open the "mpouriew" project folder in File Explorer.
2. Right-click inside the folder and choose "Open in Terminal"
   (or open PowerShell and `cd` into the project folder).
3. Run:

     powershell -ExecutionPolicy Bypass -File setup-pdfjs.ps1

   This downloads the two files directly into libs/pdfjs/.

--------------------------------------------------------------------
OPTION B — Automatic (macOS / Linux / Git Bash)
--------------------------------------------------------------------
1. Open a terminal in the project folder.
2. Run:

     bash setup-pdfjs.sh

--------------------------------------------------------------------
OPTION C — Manual download
--------------------------------------------------------------------
1. Go to: https://github.com/mozilla/pdf.js/releases
2. Download the latest "pdfjs-x.x.x-legacy-dist.zip" asset.
3. Unzip it and copy:
     build/pdf.min.js          -> libs/pdfjs/pdf.min.js
     build/pdf.worker.min.js   -> libs/pdfjs/pdf.worker.min.js
   (In some releases these are named pdf.min.mjs / pdf.worker.min.mjs —
   if so, rename them to the .js names above after copying, or update
   the two references in preview.html / preview.js accordingly.)

--------------------------------------------------------------------
Verifying it worked
--------------------------------------------------------------------
After adding the files, reload the extension at chrome://extensions
and click a PDF link on any site. If PDF.js is missing, the preview
page will show a clear "PDF viewer not installed" message instead of
failing silently.

Why isn't this bundled already?
--------------------------------------------------------------------
PDF.js is a large third-party library (several hundred KB, binary/
minified) maintained independently by Mozilla under the Apache 2.0
license. Keeping it out of this source drop keeps the delivered code
100% readable/auditable text, and ensures you always get an official,
untampered build straight from Mozilla's own releases.
