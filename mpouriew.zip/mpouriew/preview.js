/**
 * preview.js
 * ------------------------------------------------------------------
 * Drives the preview.html page:
 *   - Parses the target file URL / name / type from query params.
 *   - Fetches the file (with graceful error handling for CORS,
 *     network failures, 404s, etc).
 *   - Renders PDFs with PDF.js (all pages, smooth scroll, zoom,
 *     fit-width, page navigation).
 *   - Renders images and plain text natively.
 *   - Falls back to a "no inline preview" info card for everything
 *     else, still allowing Download / Open in New Tab.
 *   - Wires up toolbar actions: Close, Download, Open in New Tab.
 * ------------------------------------------------------------------
 */

(function () {
  "use strict";

  // ------------------------------------------------------------------
  // State
  // ------------------------------------------------------------------
  const state = {
    fileUrl: null,
    fileName: "download",
    mimeType: null,
    fileSizeBytes: null,
    scale: 1.0,
    baseWidth: null, // natural width of page 1 at scale 1, used for fit-width math
    pdfDoc: null,
    pageCount: 0,
    currentPage: 1,
    renderedPages: new Map(), // pageNumber -> wrapper element
    renderStatus: new Map(), // pageNumber -> 'pending' | 'rendering' | 'done'
    lazyObserver: null,
    isRenderingPdf: false,
    renderGeneration: 0, // bumped on every full (re)render pass to invalidate stale in-flight work
  };

  // ------------------------------------------------------------------
  // DOM references
  // ------------------------------------------------------------------
  const el = {
    fileIcon: document.getElementById("fileIcon"),
    fileName: document.getElementById("fileName"),
    fileSub: document.getElementById("fileSub"),

    closeBtn: document.getElementById("closeBtn"),
    downloadBtn: document.getElementById("downloadBtn"),
    openNewTabBtn: document.getElementById("openNewTabBtn"),

    pdfControls: document.getElementById("pdfControls"),
    zoomInBtn: document.getElementById("zoomInBtn"),
    zoomOutBtn: document.getElementById("zoomOutBtn"),
    zoomLevel: document.getElementById("zoomLevel"),
    fitWidthBtn: document.getElementById("fitWidthBtn"),
    prevPageBtn: document.getElementById("prevPageBtn"),
    nextPageBtn: document.getElementById("nextPageBtn"),
    pageInput: document.getElementById("pageInput"),
    pageCount: document.getElementById("pageCount"),

    viewerArea: document.getElementById("viewerArea"),
    loadingState: document.getElementById("loadingState"),
    loadingSub: document.getElementById("loadingSub"),
    errorState: document.getElementById("errorState"),
    errorTitle: document.getElementById("errorTitle"),
    errorMessage: document.getElementById("errorMessage"),
    errorDownloadBtn: document.getElementById("errorDownloadBtn"),
    errorOpenTabBtn: document.getElementById("errorOpenTabBtn"),

    pdfContainer: document.getElementById("pdfContainer"),
    imageContainer: document.getElementById("imageContainer"),
    previewImage: document.getElementById("previewImage"),
    textContainer: document.getElementById("textContainer"),
    previewText: document.getElementById("previewText"),
    genericContainer: document.getElementById("genericContainer"),
    genericIcon: document.getElementById("genericIcon"),
    genericDownloadBtn: document.getElementById("genericDownloadBtn"),
    genericOpenTabBtn: document.getElementById("genericOpenTabBtn"),
  };

  // ------------------------------------------------------------------
  // Utility helpers
  // ------------------------------------------------------------------

  /** Formats a byte count into a human-friendly string. */
  function formatBytes(bytes) {
    if (bytes === null || bytes === undefined || isNaN(bytes)) return null;
    if (bytes === 0) return "0 B";
    const units = ["B", "KB", "MB", "GB"];
    const i = Math.min(units.length - 1, Math.floor(Math.log(bytes) / Math.log(1024)));
    const value = bytes / Math.pow(1024, i);
    return `${value.toFixed(i === 0 ? 0 : 1)} ${units[i]}`;
  }

  /** Extracts the extension (lowercase, no dot) from a filename/URL. */
  function getExtension(name) {
    if (!name) return "";
    const clean = name.split(/[?#]/)[0];
    const match = clean.match(/\.([a-zA-Z0-9]{1,6})$/);
    return match ? match[1].toLowerCase() : "";
  }

  /** Maps an extension to a friendly icon (emoji, keeps bundle size at zero). */
  function iconForExtension(ext) {
    const map = {
      pdf: "📕",
      doc: "📘", docx: "📘",
      xls: "📗", xlsx: "📗", csv: "📗",
      ppt: "📙", pptx: "📙",
      png: "🖼️", jpg: "🖼️", jpeg: "🖼️", gif: "🖼️", webp: "🖼️", svg: "🖼️", bmp: "🖼️",
      zip: "🗜️", rar: "🗜️", "7z": "🗜️",
      txt: "📄", rtf: "📄",
    };
    return map[ext] || "📄";
  }

  /** Maps an extension to a friendly type label for the subtitle. */
  function labelForExtension(ext) {
    const map = {
      pdf: "PDF Document",
      doc: "Word Document", docx: "Word Document",
      xls: "Excel Spreadsheet", xlsx: "Excel Spreadsheet", csv: "CSV File",
      ppt: "PowerPoint Presentation", pptx: "PowerPoint Presentation",
      png: "PNG Image", jpg: "JPEG Image", jpeg: "JPEG Image",
      gif: "GIF Image", webp: "WebP Image", svg: "SVG Image", bmp: "Bitmap Image",
      zip: "ZIP Archive", rar: "RAR Archive", "7z": "7-Zip Archive",
      txt: "Text File", rtf: "Rich Text File",
    };
    return map[ext] || (ext ? `${ext.toUpperCase()} File` : "Unknown File Type");
  }

  function showOnly(sectionEl) {
    const sections = [
      el.loadingState,
      el.errorState,
      el.pdfContainer,
      el.imageContainer,
      el.textContainer,
      el.genericContainer,
    ];
    sections.forEach((s) => {
      s.hidden = s !== sectionEl;
    });
  }

  function setLoadingMessage(msg) {
    el.loadingSub.textContent = msg;
  }

  function showError(title, message) {
    el.errorTitle.textContent = title;
    el.errorMessage.textContent = message;
    showOnly(el.errorState);
  }

  // ------------------------------------------------------------------
  // Query param parsing
  // ------------------------------------------------------------------

  function parseParams() {
    const params = new URLSearchParams(window.location.search);
    const fileUrl = params.get("file");
    const name = params.get("name");
    const type = params.get("type");

    if (!fileUrl) {
      throw new Error("NO_FILE_URL");
    }

    state.fileUrl = fileUrl;
    state.fileName = name || guessFilenameFromUrl(fileUrl);
    state.mimeType = type || null;
  }

  function guessFilenameFromUrl(url) {
    try {
      const parsed = new URL(url);
      const segments = parsed.pathname.split("/").filter(Boolean);
      const last = segments[segments.length - 1];
      return last ? decodeURIComponent(last) : "download";
    } catch (err) {
      return "download";
    }
  }

  // ------------------------------------------------------------------
  // Header / metadata population
  // ------------------------------------------------------------------

  function populateHeader() {
    const ext = getExtension(state.fileName) || getExtension(state.fileUrl);
    el.fileIcon.textContent = iconForExtension(ext);
    el.fileName.textContent = state.fileName;
    el.fileName.title = state.fileName;
    updateFileSub(ext);
    return ext;
  }

  function updateFileSub(ext) {
    const parts = [labelForExtension(ext)];
    const sizeLabel = formatBytes(state.fileSizeBytes);
    if (sizeLabel) parts.push(sizeLabel);
    el.fileSub.textContent = parts.join(" • ");
  }

  // ------------------------------------------------------------------
  // Fetching the file
  // ------------------------------------------------------------------

  /**
   * Fetches the file as an ArrayBuffer, with friendly error classification.
   * Extension pages with host_permissions granted can bypass page-level
   * CORS restrictions, but we still defensively handle failures since
   * some servers actively block non-navigational requests.
   */
  async function fetchFileAsArrayBuffer(url) {
    let response;
    try {
      response = await fetch(url, { credentials: "include" });
    } catch (networkErr) {
      const err = new Error("NETWORK_ERROR");
      err.cause = networkErr;
      throw err;
    }

    if (!response.ok) {
      const err = new Error("HTTP_ERROR");
      err.status = response.status;
      throw err;
    }

    const contentType = response.headers.get("content-type");
    const contentLength = response.headers.get("content-length");
    if (contentLength) {
      state.fileSizeBytes = parseInt(contentLength, 10);
    }
    if (contentType && !state.mimeType) {
      state.mimeType = contentType.split(";")[0].trim();
    }

    const buffer = await response.arrayBuffer();
    if (!state.fileSizeBytes) {
      state.fileSizeBytes = buffer.byteLength;
    }
    return buffer;
  }

  /**
   * Lightweight, non-blocking metadata probe used for PDFs: we let
   * PDF.js stream the actual document data, but we still want file
   * size / type for the toolbar header, so we ask for just the headers.
   * Failure here is always non-fatal — the preview keeps working either way.
   */
  async function fetchHeadMetadata(url) {
    const response = await fetch(url, { method: "HEAD", credentials: "include" });
    if (!response.ok) throw new Error("HEAD_FAILED");
    const contentLength = response.headers.get("content-length");
    const contentType = response.headers.get("content-type");
    if (contentLength) state.fileSizeBytes = parseInt(contentLength, 10);
    if (contentType && !state.mimeType) state.mimeType = contentType.split(";")[0].trim();
  }

  // ------------------------------------------------------------------
  // PDF rendering (PDF.js)
  // ------------------------------------------------------------------

  function pdfJsAvailable() {
    return typeof window.pdfjsLib !== "undefined";
  }

  /**
   * Loads the PDF using PDF.js's own HTTP range-request streaming
   * (passing {url} instead of a pre-downloaded arrayBuffer). This means
   * the first page can start rendering as soon as its bytes arrive,
   * instead of waiting for the *entire* file to download first — the
   * main win for large PDFs opening quickly.
   *
   * Falls back to a plain full-file fetch + {data} load if the server
   * doesn't support range requests / streaming for some reason.
   */
  async function loadPdfDocument(url) {
    window.pdfjsLib.GlobalWorkerOptions.workerSrc = chrome.runtime.getURL(
      "libs/pdfjs/pdf.worker.min.js"
    );

    try {
      const loadingTask = window.pdfjsLib.getDocument({
        url,
        withCredentials: true,
        disableAutoFetch: true, // don't eagerly pull the whole file
        disableStream: false,
      });
      loadingTask.onProgress = (progress) => {
        if (progress && progress.total) {
          const pct = Math.round((progress.loaded / progress.total) * 100);
          setLoadingMessage(`Loading document\u2026 ${pct}%`);
        }
      };
      return await loadingTask.promise;
    } catch (streamErr) {
      // If this is a definitive, known failure (file genuinely missing,
      // corrupted, or password-protected), don't waste a second full
      // fetch — surface the precise error immediately.
      const definitiveFailures = ["MissingPDFException", "InvalidPDFException", "PasswordException", "UnexpectedResponseException"];
      if (streamErr && definitiveFailures.includes(streamErr.name)) {
        throw streamErr;
      }

      // Otherwise this is likely a server that doesn't support range
      // requests/streaming — fall back to a single full fetch and hand
      // the raw bytes to PDF.js instead.
      console.warn("[mpouriew] Streamed PDF load failed, falling back to full fetch:", streamErr);
      const buffer = await fetchFileAsArrayBuffer(url);
      const fallbackTask = window.pdfjsLib.getDocument({ data: buffer });
      return await fallbackTask.promise;
    }
  }

  async function renderPdf() {
    if (!pdfJsAvailable()) {
      throw new Error("PDFJS_MISSING");
    }

    setLoadingMessage("Loading document\u2026");

    const pdf = await loadPdfDocument(state.fileUrl);

    state.pdfDoc = pdf;
    state.pageCount = pdf.numPages;
    el.pageCount.textContent = String(pdf.numPages);
    el.pageInput.max = String(pdf.numPages);

    el.pdfControls.hidden = false;
    showOnly(el.pdfContainer);
    el.pdfContainer.innerHTML = "";
    state.renderedPages.clear();
    state.renderStatus.clear();
    state.renderGeneration += 1;

    setLoadingMessage("Preparing pages\u2026");

    // Determine base scale so that page 1 fits the available width nicely
    // by default (a sensible "Fit Width"-ish starting point).
    const firstPage = await pdf.getPage(1);
    const naturalViewport = firstPage.getViewport({ scale: 1 });
    state.baseWidth = naturalViewport.width;
    const availableWidth = Math.min(el.viewerArea.clientWidth - 48, 900);
    state.scale = Math.max(0.5, Math.min(2.5, availableWidth / naturalViewport.width));
    updateZoomLabel();

    // Build lightweight placeholders for every page immediately (cheap:
    // just sized <div>s) so the scrollbar/page count feel correct right
    // away, then render actual canvases lazily as pages approach the
    // viewport. This is what makes opening a large PDF feel instant.
    const estimatedHeight = naturalViewport.height * state.scale;
    const estimatedWidth = naturalViewport.width * state.scale;
    for (let pageNum = 1; pageNum <= pdf.numPages; pageNum++) {
      createPagePlaceholder(pageNum, estimatedWidth, estimatedHeight);
    }

    setupLazyObserver();

    // Kick off rendering of the first couple of pages right away so the
    // user sees content immediately without waiting for the observer.
    await ensurePageRendered(1);
    if (pdf.numPages > 1) ensurePageRendered(2); // fire and forget
  }

  /** Creates an empty, correctly-sized placeholder div for a page that hasn't rendered yet. */
  function createPagePlaceholder(pageNum, width, height) {
    const wrapper = document.createElement("div");
    wrapper.className = "pdf-page-wrapper pdf-page-placeholder";
    wrapper.dataset.pageNumber = String(pageNum);
    wrapper.style.width = `${Math.floor(width)}px`;
    wrapper.style.height = `${Math.floor(height)}px`;

    const spinner = document.createElement("div");
    spinner.className = "pdf-page-spinner";
    wrapper.appendChild(spinner);

    const pageLabel = document.createElement("div");
    pageLabel.className = "pdf-page-number";
    pageLabel.textContent = `Page ${pageNum} of ${state.pageCount}`;
    wrapper.appendChild(pageLabel);

    el.pdfContainer.appendChild(wrapper);
    state.renderedPages.set(pageNum, wrapper);
    state.renderStatus.set(pageNum, "pending");
  }

  // Hard ceiling on a single page canvas's backing-store pixel count.
  // Prevents runaway memory use / renderer crashes on unusually large
  // page sizes (e.g. architectural/poster-sized PDFs) combined with
  // high zoom or high-DPI screens. Quality (CSS size) is unaffected —
  // only the backing-store resolution is capped.
  const MAX_CANVAS_PIXELS = 20_000_000; // ~20 megapixels (e.g. 5000x4000)

  /** Renders the actual canvas for a page, replacing its placeholder content. Safe to call repeatedly. */
  async function ensurePageRendered(pageNum) {
    const status = state.renderStatus.get(pageNum);
    if (status === "done" || status === "rendering") return;
    state.renderStatus.set(pageNum, "rendering");

    // Snapshot which "generation" of the document/zoom level we're
    // rendering for. If the user zooms or the doc reloads while this
    // page is mid-flight, we detect the mismatch below and bail out
    // instead of corrupting the DOM with a stale render.
    const myGeneration = state.renderGeneration;

    try {
      const page = await state.pdfDoc.getPage(pageNum);
      if (myGeneration !== state.renderGeneration) return; // stale: abandon

      const viewport = page.getViewport({ scale: state.scale });

      const wrapper = state.renderedPages.get(pageNum);
      if (!wrapper) return;

      wrapper.classList.remove("pdf-page-placeholder");
      wrapper.innerHTML = "";
      wrapper.style.width = `${Math.floor(viewport.width)}px`;
      wrapper.style.height = `${Math.floor(viewport.height)}px`;

      const canvas = document.createElement("canvas");
      const context = canvas.getContext("2d");

      // Cap the backing-store resolution so width*height*dpr^2 never
      // exceeds MAX_CANVAS_PIXELS, avoiding out-of-memory canvas errors.
      let outputScale = window.devicePixelRatio || 1;
      const rawArea = viewport.width * viewport.height * outputScale * outputScale;
      if (rawArea > MAX_CANVAS_PIXELS) {
        outputScale = Math.max(1, Math.sqrt(MAX_CANVAS_PIXELS / (viewport.width * viewport.height)));
      }

      canvas.width = Math.max(1, Math.floor(viewport.width * outputScale));
      canvas.height = Math.max(1, Math.floor(viewport.height * outputScale));
      canvas.style.width = `${Math.floor(viewport.width)}px`;
      canvas.style.height = `${Math.floor(viewport.height)}px`;

      const transform = outputScale !== 1 ? [outputScale, 0, 0, outputScale, 0, 0] : null;

      const pageLabel = document.createElement("div");
      pageLabel.className = "pdf-page-number";
      pageLabel.textContent = `Page ${pageNum} of ${state.pageCount}`;

      wrapper.appendChild(canvas);
      wrapper.appendChild(pageLabel);

      await page.render({ canvasContext: context, viewport, transform }).promise;

      if (myGeneration !== state.renderGeneration) return; // stale: don't mark as done
      state.renderStatus.set(pageNum, "done");
    } catch (err) {
      if (myGeneration !== state.renderGeneration) return; // superseded, ignore the error
      console.error(`[mpouriew] Failed to render page ${pageNum}:`, err);
      state.renderStatus.set(pageNum, "pending"); // allow retry on next intersection
    }
  }

  /**
   * Reverts a previously-rendered page back to a lightweight placeholder,
   * freeing its canvas's (potentially large) pixel memory. This is the
   * "windowing" step that lets even documents with hundreds/thousands of
   * pages stay light in memory — only pages near the viewport are ever
   * kept as real canvases at once.
   */
  function unrenderPage(pageNum) {
    if (state.renderStatus.get(pageNum) !== "done") return;
    const wrapper = state.renderedPages.get(pageNum);
    if (!wrapper) return;

    // Keep the wrapper's existing width/height (already sized to the
    // rendered viewport) so scroll position doesn't jump.
    wrapper.innerHTML = "";
    wrapper.classList.add("pdf-page-placeholder");

    const spinner = document.createElement("div");
    spinner.className = "pdf-page-spinner";
    wrapper.appendChild(spinner);

    const pageLabel = document.createElement("div");
    pageLabel.className = "pdf-page-number";
    pageLabel.textContent = `Page ${pageNum} of ${state.pageCount}`;
    wrapper.appendChild(pageLabel);

    state.renderStatus.set(pageNum, "pending");
  }

  /**
   * Watches all page placeholders and lazily triggers real rendering
   * once a page is close to (or inside) the visible viewport, instead
   * of rendering every page up front.
   */
  function setupLazyObserver() {
    if (state.lazyObserver) {
      state.lazyObserver.disconnect();
    }

    state.lazyObserver = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          const pageNum = parseInt(entry.target.dataset.pageNumber, 10);
          if (entry.isIntersecting) {
            ensurePageRendered(pageNum);
            state.currentPage = pageNum;
            el.pageInput.value = String(pageNum);
          } else {
            // Page scrolled out beyond the render margin: free its canvas
            // memory. It will be re-rendered automatically if the user
            // scrolls back. This "windowing" keeps memory bounded no
            // matter how many pages the document has.
            unrenderPage(pageNum);
          }
        });
      },
      {
        root: el.viewerArea,
        // Start rendering ~1.5 viewport-heights before a page is visible
        // so scrolling feels smooth instead of "popping in".
        rootMargin: "1200px 0px",
        threshold: 0.01,
      }
    );

    state.renderedPages.forEach((wrapper) => state.lazyObserver.observe(wrapper));
  }

  /** Re-renders visible pages at the current scale (used by zoom / fit width). */
  async function rerenderAllPages() {
    if (!state.pdfDoc || state.isRenderingPdf) return;
    state.isRenderingPdf = true;
    try {
      const scrollRatio =
        el.viewerArea.scrollTop / Math.max(1, el.viewerArea.scrollHeight - el.viewerArea.clientHeight);

      const firstPage = await state.pdfDoc.getPage(1);
      const naturalViewport = firstPage.getViewport({ scale: 1 });
      const estimatedHeight = naturalViewport.height * state.scale;
      const estimatedWidth = naturalViewport.width * state.scale;

      el.pdfContainer.innerHTML = "";
      state.renderedPages.clear();
      state.renderStatus.clear();
      state.renderGeneration += 1;

      for (let pageNum = 1; pageNum <= state.pdfDoc.numPages; pageNum++) {
        createPagePlaceholder(pageNum, estimatedWidth, estimatedHeight);
      }
      setupLazyObserver();

      // Re-render whichever page the user was looking at immediately.
      await ensurePageRendered(state.currentPage || 1);

      requestAnimationFrame(() => {
        el.viewerArea.scrollTop =
          scrollRatio * (el.viewerArea.scrollHeight - el.viewerArea.clientHeight);
      });
    } finally {
      state.isRenderingPdf = false;
    }
  }

  function updateZoomLabel() {
    el.zoomLevel.textContent = `${Math.round(state.scale * 100)}%`;
  }

  function zoomIn() {
    state.scale = Math.min(3.5, state.scale + 0.15);
    updateZoomLabel();
    rerenderAllPages();
  }

  function zoomOut() {
    state.scale = Math.max(0.3, state.scale - 0.15);
    updateZoomLabel();
    rerenderAllPages();
  }

  function fitWidth() {
    if (!state.baseWidth) return;
    const availableWidth = el.viewerArea.clientWidth - 48;
    state.scale = Math.max(0.3, Math.min(3.5, availableWidth / state.baseWidth));
    updateZoomLabel();
    rerenderAllPages();
  }

  function goToPage(pageNum) {
    const clamped = Math.max(1, Math.min(state.pageCount, pageNum));
    const wrapper = state.renderedPages.get(clamped);
    if (wrapper) {
      wrapper.scrollIntoView({ behavior: "smooth", block: "start" });
    }
  }

  // ------------------------------------------------------------------
  // Image / text rendering
  // ------------------------------------------------------------------

  function renderImage(objectUrl) {
    el.previewImage.src = objectUrl;
    showOnly(el.imageContainer);
  }

  function renderText(text) {
    // Cap extremely large text files to keep the DOM responsive.
    const MAX_CHARS = 500000;
    el.previewText.textContent =
      text.length > MAX_CHARS
        ? text.slice(0, MAX_CHARS) + "\n\n… (truncated, download the file to see the full contents)"
        : text;
    showOnly(el.textContainer);
  }

  function renderGenericFallback(ext) {
    el.genericIcon.textContent = iconForExtension(ext);
    showOnly(el.genericContainer);
  }

  // Safety ceilings: files above these sizes skip inline rendering and
  // go straight to the "download instead" card, so an unusually large
  // file can never hang or crash the preview tab.
  const MAX_TEXT_PREVIEW_BYTES = 20 * 1024 * 1024; // 20 MB
  const MAX_IMAGE_PREVIEW_BYTES = 60 * 1024 * 1024; // 60 MB

  /**
   * Checks the file's size (via a quick HEAD request) before committing to
   * a full in-memory fetch. If it's over the given ceiling, throws a
   * TOO_LARGE error that the caller routes to the generic fallback UI
   * instead of attempting to render it inline.
   */
  async function guardAgainstOversizedFile(ext, maxBytes) {
    try {
      await fetchHeadMetadata(state.fileUrl);
    } catch (err) {
      return; // HEAD not supported/blocked — proceed optimistically.
    }
    if (state.fileSizeBytes && state.fileSizeBytes > maxBytes) {
      const err = new Error("TOO_LARGE");
      err.ext = ext;
      throw err;
    }
  }

  // ------------------------------------------------------------------
  // Main load flow
  // ------------------------------------------------------------------

  async function loadAndRender() {
    showOnly(el.loadingState);
    setLoadingMessage("Fetching file\u2026");

    const ext = populateHeader();

    try {
      if (ext === "pdf" || state.mimeType === "application/pdf") {
        // Kick off a lightweight metadata fetch (size/type for the header)
        // in the background — it must never block rendering.
        fetchHeadMetadata(state.fileUrl).then(() => updateFileSub(ext)).catch(() => {});
        await renderPdf();
        return;
      }

      const imageExts = ["png", "jpg", "jpeg", "gif", "webp", "svg", "bmp"];
      if (imageExts.includes(ext)) {
        await guardAgainstOversizedFile(ext, MAX_IMAGE_PREVIEW_BYTES);
        const buffer = await fetchFileAsArrayBuffer(state.fileUrl);
        updateFileSub(ext);
        const blob = new Blob([buffer], { type: state.mimeType || `image/${ext}` });
        renderImage(URL.createObjectURL(blob));
        return;
      }

      const textExts = ["txt", "csv"];
      if (textExts.includes(ext)) {
        await guardAgainstOversizedFile(ext, MAX_TEXT_PREVIEW_BYTES);
        const buffer = await fetchFileAsArrayBuffer(state.fileUrl);
        updateFileSub(ext);
        const text = new TextDecoder("utf-8").decode(buffer);
        renderText(text);
        return;
      }

      // Unknown / unsupported for inline rendering (docx, xlsx, pptx, zip, etc).
      // We only need the file size/type for the header — never download
      // the whole file just to show an info card, especially for large files.
      try {
        await fetchHeadMetadata(state.fileUrl);
      } catch (sizeErr) {
        // Non-fatal: we simply won't know the size ahead of time.
      }
      updateFileSub(ext);
      renderGenericFallback(ext);
    } catch (err) {
      if (err && err.message === "TOO_LARGE") {
        updateFileSub(ext);
        showOnly(el.genericContainer);
        el.genericIcon.textContent = iconForExtension(ext);
        document.querySelector("#genericContainer .state-title").textContent = "File too large to preview inline";
        document.querySelector("#genericContainer .state-sub").textContent =
          `This file is ${formatBytes(state.fileSizeBytes)}, which is too large to render safely in the browser. You can still download it or open it in a new tab.`;
        return;
      }
      handleLoadError(err, ext);
    }
  }

  function handleLoadError(err, ext) {
    console.error("[mpouriew] Failed to load/render file:", err);

    if (err && err.message === "PDFJS_MISSING") {
      showError(
        "PDF viewer not installed",
        "The PDF.js library files are missing from libs/pdfjs/. See libs/pdfjs/README.txt for setup instructions. You can still download the file below."
      );
      return;
    }

    // PDF.js-specific exceptions thrown by getDocument({url: ...}).
    if (err && err.name === "MissingPDFException") {
      showError("File not found", "The server couldn't find this PDF — it may have been moved or deleted.");
      return;
    }
    if (err && err.name === "UnexpectedResponseException") {
      showError("Couldn't load file", `The server responded unexpectedly${err.status ? ` (HTTP ${err.status})` : ""}.`);
      return;
    }
    if (err && err.name === "InvalidPDFException") {
      showError("This PDF looks corrupted", "The file couldn't be parsed as a valid PDF. It may be incomplete or damaged.");
      return;
    }
    if (err && err.name === "PasswordException") {
      showError("Password-protected PDF", "This PDF is encrypted and can't be previewed. You can still download it and open it with a PDF reader that supports passwords.");
      return;
    }

    if (err && err.message === "HTTP_ERROR") {
      if (err.status === 404) {
        showError("File not found", "The server responded with a 404 — this file may have been moved or deleted.");
      } else if (err.status === 401 || err.status === 403) {
        showError(
          "Access denied",
          `The server refused this request (HTTP ${err.status}). You may need to be logged in on the original site.`
        );
      } else {
        showError("Couldn't load file", `The server responded with HTTP ${err.status}.`);
      }
      return;
    }

    if (err && err.message === "NETWORK_ERROR") {
      showError(
        "Network or CORS error",
        "The file couldn't be fetched. This can happen if the server blocks cross-origin requests, the link is broken, or you're offline."
      );
      return;
    }

    if (err && /invalid pdf|corrupt/i.test(err.message || "")) {
      showError("This PDF looks corrupted", "The file couldn't be parsed as a valid PDF. It may be incomplete or damaged.");
      return;
    }

    showError("Something went wrong", "This file couldn't be previewed. You can still try downloading it directly.");
  }

  // ------------------------------------------------------------------
  // Toolbar actions
  // ------------------------------------------------------------------

  function triggerDownload() {
    chrome.runtime.sendMessage(
      { type: "DOWNLOAD_FILE", payload: { fileUrl: state.fileUrl, fileName: state.fileName } },
      (response) => {
        if (!response || !response.ok) {
          console.warn("[mpouriew] Download via API failed, falling back to direct link.", response && response.error);
          // Fallback: open the raw URL, letting Chrome's native download flow take over.
          window.open(state.fileUrl, "_blank");
        }
      }
    );
  }

  function openInNewTab() {
    window.open(state.fileUrl, "_blank", "noopener,noreferrer");
  }

  function closePreview() {
    window.close();
    // Some Chrome versions restrict window.close() for tabs not opened by
    // script from the same page context; as a fallback, navigate back.
    setTimeout(() => {
      if (!window.closed && history.length > 1) {
        history.back();
      }
    }, 150);
  }

  function wireUpEvents() {
    el.closeBtn.addEventListener("click", closePreview);
    el.downloadBtn.addEventListener("click", triggerDownload);
    el.openNewTabBtn.addEventListener("click", openInNewTab);

    el.errorDownloadBtn.addEventListener("click", triggerDownload);
    el.errorOpenTabBtn.addEventListener("click", openInNewTab);
    el.genericDownloadBtn.addEventListener("click", triggerDownload);
    el.genericOpenTabBtn.addEventListener("click", openInNewTab);

    el.zoomInBtn.addEventListener("click", zoomIn);
    el.zoomOutBtn.addEventListener("click", zoomOut);
    el.fitWidthBtn.addEventListener("click", fitWidth);

    el.prevPageBtn.addEventListener("click", () => goToPage(state.currentPage - 1));
    el.nextPageBtn.addEventListener("click", () => goToPage(state.currentPage + 1));
    el.pageInput.addEventListener("change", () => {
      const val = parseInt(el.pageInput.value, 10);
      if (!isNaN(val)) goToPage(val);
    });

    // Keyboard shortcuts: Esc to close, +/- to zoom.
    document.addEventListener("keydown", (e) => {
      if (e.key === "Escape") closePreview();
      if (e.key === "+" || e.key === "=") zoomIn();
      if (e.key === "-" || e.key === "_") zoomOut();
    });

    // Re-fit on window resize (debounced) so the layout stays responsive.
    let resizeTimer = null;
    window.addEventListener("resize", () => {
      if (!state.pdfDoc) return;
      clearTimeout(resizeTimer);
      resizeTimer = setTimeout(fitWidth, 250);
    });
  }

  // ------------------------------------------------------------------
  // Entry point
  // ------------------------------------------------------------------

  function init() {
    wireUpEvents();
    try {
      parseParams();
    } catch (err) {
      showError("No file specified", "This preview page was opened without a valid file URL.");
      return;
    }
    loadAndRender();
  }

  document.addEventListener("DOMContentLoaded", init);
})();
