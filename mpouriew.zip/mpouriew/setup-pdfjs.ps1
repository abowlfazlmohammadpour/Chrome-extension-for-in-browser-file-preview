<#
  setup-pdfjs.ps1
  ------------------------------------------------------------------
  Downloads the two PDF.js runtime files required by the "mpouriew"
  Chrome extension and places them in libs\pdfjs\.

  Usage (from the project root, in PowerShell):
      powershell -ExecutionPolicy Bypass -File setup-pdfjs.ps1
------------------------------------------------------------------ #>

$ErrorActionPreference = "Stop"

$version   = "3.11.174"  # Known-good pdfjs-dist legacy build
$baseUrl   = "https://cdn.jsdelivr.net/npm/pdfjs-dist@$version/legacy/build"
$targetDir = Join-Path $PSScriptRoot "libs\pdfjs"

if (!(Test-Path $targetDir)) {
    New-Item -ItemType Directory -Path $targetDir -Force | Out-Null
}

$files = @{
    "pdf.min.js"        = "$baseUrl/pdf.min.js"
    "pdf.worker.min.js" = "$baseUrl/pdf.worker.min.js"
}

foreach ($fileName in $files.Keys) {
    $url  = $files[$fileName]
    $dest = Join-Path $targetDir $fileName
    Write-Host "Downloading $fileName ..."
    try {
        Invoke-WebRequest -Uri $url -OutFile $dest -UseBasicParsing
        Write-Host "  -> Saved to $dest"
    } catch {
        Write-Warning "  Failed to download $fileName from $url"
        Write-Warning "  Please download it manually (see libs\pdfjs\README.txt)."
    }
}

Write-Host ""
Write-Host "Done. Reload the extension at chrome://extensions to pick up the changes."
