/**
 * content.js
 * ------------------------------------------------------------------
 * Injected into every page. Listens for clicks on anchor tags (or
 * elements nested inside anchor tags) that point to a "downloadable"
 * file - especially PDFs - and redirects the action to our preview
 * page instead of letting the browser download the file immediately.
 *
 * Design goals:
 *   - Be conservative: only intercept links we're fairly confident are
 *     direct file downloads, so we don't break normal site navigation.
 *   - Never intercept if the user explicitly wants the native browser
 *     behavior (Ctrl/Cmd+Click for new tab, Shift+Click, middle-click,
 *     or links inside the extension's own preview page).
 *   - Fail open: if anything is uncertain, let the browser handle it
 *     normally rather than blocking the user's download.
 * ------------------------------------------------------------------
 */

(function () {
  "use strict";

  // File extensions we consider "downloadable documents" worth previewing.
  const PREVIEWABLE_EXTENSIONS = [
    "pdf",
    "doc", "docx",
    "xls", "xlsx",
    "ppt", "pptx",
    "txt", "csv", "rtf",
    "png", "jpg", "jpeg", "gif", "webp", "svg", "bmp",
    "zip", "rar", "7z"
  ];

  // Extensions we can actually *render* inside the preview (vs. just
  // showing file info + download button). Kept in preview.js too, but
  // duplicated here as a quick reference for future maintainers.
  // PDF -> full PDF.js rendering
  // images/txt -> native <img>/<pre> rendering
  // everything else -> info card with download / open externally

  const MAX_URL_LENGTH = 8000; // sanity guard against pathological URLs

  /**
   * Extracts the lowercase file extension from a URL's pathname,
   * ignoring query strings and hash fragments.
   */
  function getExtensionFromUrl(url) {
    try {
      const parsed = new URL(url, window.location.href);
      const pathname = parsed.pathname || "";
      const match = pathname.match(/\.([a-zA-Z0-9]{1,6})$/);
      return match ? match[1].toLowerCase() : null;
    } catch (err) {
      return null;
    }
  }

  /**
   * Determines whether a given anchor element should be intercepted.
   */
  function isInterceptableAnchor(anchor) {
    if (!anchor || !anchor.href) return false;
    if (anchor.href.length > MAX_URL_LENGTH) return false;

    // Respect explicit opt-outs some sites might use.
    if (anchor.hasAttribute("data-mpouriew-ignore")) return false;

    // Skip javascript:, mailto:, tel:, and same-page anchors.
    const rawHref = anchor.getAttribute("href") || "";
    if (/^(javascript:|mailto:|tel:|#)/i.test(rawHref.trim())) return false;

    let url;
    try {
      url = new URL(anchor.href, window.location.href);
    } catch (err) {
      return false;
    }

    if (!["http:", "https:", "blob:"].includes(url.protocol)) return false;

    // If the site explicitly marked this as a download of a
    // previewable type, honor that first.
    const hasDownloadAttr = anchor.hasAttribute("download");

    const extension = getExtensionFromUrl(anchor.href);
    const looksPreviewable = extension && PREVIEWABLE_EXTENSIONS.includes(extension);

    // Some download endpoints don't have a file extension in the URL
    // (e.g. /files/download?id=123) but do carry a "download" attribute
    // or obvious keywords. We still try to preview these; preview.js
    // will gracefully fall back to a generic file-info view if it can't
    // determine a renderable type.
    const looksLikeDownloadEndpoint =
      hasDownloadAttr ||
      /\/(download|attachment|export)(\/|\?|$)/i.test(url.pathname + url.search);

    return Boolean(looksPreviewable || (hasDownloadAttr && looksLikeDownloadEndpoint));
  }

  /**
   * Walks up the DOM from the click target to find the nearest anchor.
   */
  function findAnchorAncestor(node) {
    let el = node;
    while (el && el !== document.body && el.tagName !== "A") {
      el = el.parentElement;
    }
    return el && el.tagName === "A" ? el : null;
  }

  /**
   * Guesses a human-friendly filename from a URL.
   */
  function guessFilenameFromUrl(url) {
    try {
      const parsed = new URL(url);
      const segments = parsed.pathname.split("/").filter(Boolean);
      const last = segments[segments.length - 1];
      return last ? decodeURIComponent(last) : "download";
    } catch (err) {
      return "download";
    }
  }

  /**
   * Main click handler. Uses the capture phase so we get first crack
   * at the event before site-specific handlers can stopPropagation().
   */
  document.addEventListener(
    "click",
    function (event) {
      // Let the user override our interception with modifier keys or
      // middle-click, matching standard browser "open in new tab" UX.
      if (
        event.defaultPrevented ||
        event.button !== 0 || // only left-click
        event.metaKey ||
        event.ctrlKey ||
        event.shiftKey ||
        event.altKey
      ) {
        return;
      }

      const anchor = findAnchorAncestor(event.target);
      if (!anchor) return;
      if (!isInterceptableAnchor(anchor)) return;

      // We're confident enough to intercept: stop the native download
      // and hand off to the background service worker.
      event.preventDefault();
      event.stopPropagation();

      const fileUrl = anchor.href;
      const downloadAttr = anchor.getAttribute("download");
      const fileName =
        (downloadAttr && downloadAttr.trim()) || guessFilenameFromUrl(fileUrl);

      chrome.runtime.sendMessage(
        {
          type: "OPEN_PREVIEW",
          payload: { fileUrl, fileName }
        },
        (response) => {
          if (chrome.runtime.lastError || !response || !response.ok) {
            // Fail open: if messaging the background worker fails for
            // any reason, fall back to a normal navigation so the user
            // isn't stuck with a dead click.
            console.warn(
              "[mpouriew] Could not open preview, falling back to direct navigation.",
              chrome.runtime.lastError || (response && response.error)
            );
            window.location.href = fileUrl;
          }
        }
      );
    },
    true // capture phase
  );
})();
