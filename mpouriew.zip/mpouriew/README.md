# mpouriew — In-Browser File Preview for Chrome

![Manifest V3](https://img.shields.io/badge/Manifest-V3-blue)
![License: MIT](https://img.shields.io/badge/License-MIT-green.svg)
![Platform: Chrome](https://img.shields.io/badge/Platform-Chrome-yellow)

A Manifest V3 Chrome extension that intercepts downloadable file links
(especially PDFs) and shows a clean, modern in-browser preview before
any file actually downloads.

**No frameworks, no build step** — plain HTML/CSS/JS, using [PDF.js](https://github.com/mozilla/pdf.js) for rendering.

---

### Table of Contents
- [Folder Structure](#1-folder-structure)
- [Installation](#2-installation)
- [Usage](#3-usage)
- [Permissions Used](#4-permissions-used-and-why)
- [Error Handling](#5-error-handling)
- [Limitations](#6-limitations-of-chrome-extension-apis-be-aware-of-these)
- [Future Improvements](#7-future-improvements)
- [Security Notes](#8-security-notes)
- [License](#license)

---

## 1. Folder Structure

```
mpouriew/
├── manifest.json          # Manifest V3 config
├── background.js          # Service worker: opens preview tab, handles downloads
├── content.js              # Injected into every page: intercepts link clicks
├── preview.html            # The preview UI shell
├── preview.css             # Styling (light, minimal, rounded, professional)
├── preview.js               # Preview logic: fetch, render, zoom, download
├── setup-pdfjs.ps1          # Windows helper: downloads PDF.js files
├── setup-pdfjs.sh           # macOS/Linux helper: downloads PDF.js files
├── icons/
│   ├── icon16.png
│   ├── icon48.png
│   └── icon128.png
└── libs/
    └── pdfjs/
        ├── README.txt        # How to add PDF.js (required, one-time step)
        ├── pdf.min.js         # (added by you — see step 2 below)
        └── pdf.worker.min.js  # (added by you — see step 2 below)
```

---

## 2. Installation

### Step 1 — Get the project onto your machine
Unzip/copy the `mpouriew` folder anywhere on your Windows machine, e.g.
`C:\Users\<you>\Documents\mpouriew`.

### Step 2 — Add the PDF.js library (one-time, required for PDF rendering)
This extension renders PDFs with **PDF.js**. To keep the delivered source
100% plain, auditable text, the two PDF.js runtime files are fetched by a
small helper script instead of being pasted in as binary blobs.

Open PowerShell in the project folder and run:

```powershell
powershell -ExecutionPolicy Bypass -File setup-pdfjs.ps1
```

This downloads `pdf.min.js` and `pdf.worker.min.js` into `libs/pdfjs/`.
(macOS/Linux users: run `bash setup-pdfjs.sh` instead.) If you'd rather
do it by hand, see `libs/pdfjs/README.txt` for the manual steps.

> Without this step, the extension still works for images, text files,
> and other file types — it will simply show a friendly "PDF viewer not
> installed" message instead of rendering PDFs.

### Step 3 — Load the extension in Chrome
1. Open Chrome and go to `chrome://extensions`.
2. Turn on **Developer mode** (top-right toggle).
3. Click **Load unpacked**.
4. Select the `mpouriew` folder.
5. The extension should now appear in your extensions list with its icon.

### Step 4 — Try it out
Visit any page with a PDF link (for example, search for "sample pdf
download" or open a report/invoice link) and click it. Instead of
downloading immediately, the mpouriew preview tab should open.

---

## 3. Usage

- **Click a PDF (or other supported) link** on any website → a new tab
  opens showing the mpouriew preview instead of downloading immediately.
- **Toolbar controls:**
  - `✕` — Close the preview tab.
  - File name / size / type — shown next to a file-type icon.
  - `−` / `100%` / `+` — Zoom out / current zoom / zoom in (PDF only).
  - `Fit Width` — Rescales the PDF to fit the viewer width.
  - `↑` / page number / `↓` — Jump between pages (PDF only).
  - `Open in New Tab` — Opens the original file URL directly in a new tab.
  - `Download` — Downloads the original file via Chrome's Downloads API.
- **Keyboard shortcuts (inside the preview tab):** `Esc` closes the tab,
  `+`/`-` zoom in/out.
- **Modifier-key clicks are respected:** Ctrl/Cmd-click, Shift-click, and
  middle-click on a link behave like normal browser tabs/downloads and
  are **not** intercepted, matching users' usual expectations.

### What gets intercepted
- Direct links ending in `.pdf`, `.doc(x)`, `.xls(x)`, `.ppt(x)`, `.txt`,
  `.csv`, `.rtf`, common image formats, and archive formats.
- Anchor tags with a `download` attribute pointing at a recognized file
  type, or at a URL path that looks like a download endpoint
  (`/download`, `/attachment`, `/export`, etc.).
- A site can opt an individual link out of interception by adding
  `data-mpouriew-ignore` to the `<a>` tag.

### What gets rendered inline vs. just shown as info
| Type | Behavior |
|---|---|
| PDF | Full PDF.js rendering: all pages, smooth scroll, zoom, fit width, page nav |
| PNG / JPG / GIF / WebP / SVG / BMP | Rendered natively as an image |
| TXT / CSV | Rendered as plain text |
| DOC(X), XLS(X), PPT(X), ZIP, RAR, 7z, etc. | Shown as a file-info card (name, size, type) with Download / Open in New Tab — browsers can't render these formats natively, so no inline preview is attempted |

---

## 4. Permissions Used (and why)

| Permission | Reason |
|---|---|
| `downloads` | Required to trigger the actual file download via `chrome.downloads.download()` when the user clicks **Download**. |
| `storage` | Used to keep a short-lived, session-scoped record of URLs the user explicitly chose to download (housekeeping to avoid feedback loops). |
| `activeTab` | Lets the extension act on the tab the user is currently interacting with without broader always-on access. |
| `scripting` | Declared for MV3 content-script infrastructure/future dynamic injection needs. |
| `host_permissions: <all_urls>` | Needed so (a) the content script can detect download links on any site, and (b) the preview page can `fetch()` the target file cross-origin (extensions with host permissions are exempt from page-level CORS blocking, which lets PDFs from other domains be fetched for rendering). |

No analytics, telemetry, or remote-code permissions are requested.

---

## 5. Error Handling

The preview page distinguishes between and clearly messages:
- **404 / broken links** — "File not found."
- **401 / 403** — "Access denied" (e.g., requires login on the source site).
- **Network / CORS failures** — explained in plain language, with a
  Download / Open in New Tab fallback so the user is never stuck.
- **Corrupted or invalid PDFs** — caught via PDF.js load errors.
- **Missing PDF.js files** — a clear one-line explanation instead of a
  blank page or console-only error.
- **Unsupported types** — a graceful "no inline preview available" card,
  never a hard failure.

---

## 6. Limitations of Chrome Extension APIs (be aware of these)

- **`window.close()` restrictions**: Chrome only allows a script to close
  a tab it opened itself via `window.open`. Since our preview tab is
  opened via `chrome.tabs.create` from the background worker, some Chrome
  versions may not allow `window.close()` to work from inside the tab; we
  fall back to `history.back()` when that happens, but on a freshly
  opened tab with no history, the tab may need to be closed manually.
  A more robust fix (see Future Improvements) is to have the preview page
  message the background worker to call `chrome.tabs.remove()`.
- **CORS bypass is not absolute**: while extensions with `host_permissions`
  are generally exempt from browser-enforced CORS, some servers use other
  protections (e.g., requiring specific auth headers, IP allow-lists, or
  bot-detection) that will still block the fetch.
- **`declarativeNetRequest`** was intentionally **not** used. It's built
  for blocking/redirecting network *requests*, not for intercepting user
  *clicks* before navigation — link interception is more reliably done at
  the DOM level in a content script, which is the approach this project
  uses. Adding `declarativeNetRequest` without a concrete redirect rule
  would only add an unused, unnecessary permission.
  If you have a Windows Chrome-native "Save As" download-flow requirement
  triggered outside of a page click (e.g., context-menu "Save Link As"),
  that flow bypasses content scripts entirely — this is a Chrome platform
  limitation, not something any extension can intercept.
- **File System Access is read-only in previews**: the extension previews
  files fetched over HTTP(S)/blob — it does not (and cannot, without the
  broader `downloads.open` / native file system permissions) preview files
  already sitting on the user's local disk unless they're served over
  `file://` with the appropriate Chrome flag enabled.
- **Large files**: extremely large PDFs or text files may be slow to
  render because PDF.js renders every page up front in this build (by
  design, per the "show all pages" requirement). Very large files could
  be memory-intensive.

---

## 7. Future Improvements

- Switch tab-closing to a `chrome.tabs.remove()` message-based approach
  for 100% reliable closing regardless of how the tab was opened.
- Add virtualized/lazy PDF page rendering (render pages as they scroll
  into view) to handle very large PDFs more efficiently.
- Add a dark mode toggle.
- Add DOCX/XLSX/PPTX inline rendering via a WASM-based converter (e.g.,
  rendering DOCX to HTML) for a true inline preview instead of the
  file-info fallback card.
- Add a small options page to let users allow-list/block-list specific
  domains or file types from being intercepted.
- Add PDF text search (PDF.js supports a text layer that can be enabled
  for find-in-page and text selection/copy).
- Persist the user's last zoom level/preferences via `chrome.storage.sync`.

---

## 8. Security Notes

- No remote code execution: all scripts are bundled locally and the
  extension's Content-Security-Policy restricts `script-src` to `'self'`.
- Filenames used for downloads are sanitized to strip characters that
  are invalid in Windows file paths.
- The extension only acts on left-clicks without modifier keys, and only
  on links it's confident are file downloads — normal site navigation is
  left completely untouched.
- URLs are validated (`http:`, `https:`, `blob:`, `data:`, `file:` only)
  before any preview/download action is taken.

---

## License

This project is licensed under the [MIT License](LICENSE).

It uses [PDF.js](https://github.com/mozilla/pdf.js) for rendering, which is
licensed separately by Mozilla under the Apache License 2.0 and is **not**
bundled in this repository — see `libs/pdfjs/README.txt` for how to add it.
