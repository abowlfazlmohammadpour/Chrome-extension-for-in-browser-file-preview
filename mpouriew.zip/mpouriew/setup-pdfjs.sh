#!/usr/bin/env bash
# ------------------------------------------------------------------
# setup-pdfjs.sh
# Downloads the two PDF.js runtime files required by the "mpouriew"
# Chrome extension and places them in libs/pdfjs/.
#
# Usage (from the project root):
#   bash setup-pdfjs.sh
# ------------------------------------------------------------------
set -euo pipefail

VERSION="3.11.174"  # Known-good pdfjs-dist legacy build
BASE_URL="https://cdn.jsdelivr.net/npm/pdfjs-dist@${VERSION}/legacy/build"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TARGET_DIR="${SCRIPT_DIR}/libs/pdfjs"

mkdir -p "${TARGET_DIR}"

download() {
  local name="$1"
  local url="${BASE_URL}/${name}"
  local dest="${TARGET_DIR}/${name}"
  echo "Downloading ${name} ..."
  if command -v curl >/dev/null 2>&1; then
    curl -fsSL "${url}" -o "${dest}"
  elif command -v wget >/dev/null 2>&1; then
    wget -q "${url}" -O "${dest}"
  else
    echo "Error: neither curl nor wget is available." >&2
    exit 1
  fi
  echo "  -> Saved to ${dest}"
}

download "pdf.min.js"
download "pdf.worker.min.js"

echo ""
echo "Done. Reload the extension at chrome://extensions to pick up the changes."
