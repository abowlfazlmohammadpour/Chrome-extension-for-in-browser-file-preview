/**
 * background.js
 * ------------------------------------------------------------------
 * Service worker (Manifest V3) for the "mpouriew" extension.
 *
 * Responsibilities:
 *   1. Receive "openPreview" messages from content scripts when a user
 *      clicks a downloadable file link, and open preview.html in a new
 *      tab with the target file's URL passed along as a query param.
 *   2. Receive "downloadFile" messages from the preview page and trigger
 *      the actual download using the chrome.downloads API.
 *   3. Keep a small in-memory + storage-backed cache of "recently
 *      intercepted" URLs so we don't accidentally re-intercept a file
 *      that the user explicitly asked to download from the preview UI.
 *
 * Security notes:
 *   - We never eval() or execute remote code.
 *   - We validate URLs before acting on them.
 *   - We only ever open our own bundled preview.html page.
 * ------------------------------------------------------------------
 */

// Keys used in chrome.storage.session for short-lived state.
const ALLOW_LIST_KEY = "mpouriew_allowed_downloads";

/**
 * Basic URL validation. We only want http(s), and data/blob URLs that
 * originate from a page (blob: is common for in-page generated PDFs).
 */
function isSupportedUrl(url) {
  try {
    const parsed = new URL(url);
    return ["http:", "https:", "blob:", "data:", "file:"].includes(parsed.protocol);
  } catch (err) {
    return false;
  }
}

/**
 * Build the internal preview.html URL, forwarding the original file
 * URL, a suggested filename, and (optionally) a MIME type hint.
 */
function buildPreviewUrl({ fileUrl, fileName, mimeType }) {
  const previewPageUrl = chrome.runtime.getURL("preview.html");
  const params = new URLSearchParams();
  params.set("file", fileUrl);
  if (fileName) params.set("name", fileName);
  if (mimeType) params.set("type", mimeType);
  return `${previewPageUrl}?${params.toString()}`;
}

/**
 * Mark a URL as "allowed" so that if the download itself triggers a
 * navigation that looks like another download attempt, we don't loop.
 * Stored in session storage with a short TTL via timestamp check.
 */
async function markUrlAsAllowed(url) {
  const data = await chrome.storage.session.get(ALLOW_LIST_KEY);
  const list = data[ALLOW_LIST_KEY] || {};
  list[url] = Date.now();
  // Prune entries older than 5 minutes to keep storage tidy.
  const fiveMinutesAgo = Date.now() - 5 * 60 * 1000;
  for (const key of Object.keys(list)) {
    if (list[key] < fiveMinutesAgo) delete list[key];
  }
  await chrome.storage.session.set({ [ALLOW_LIST_KEY]: list });
}

/**
 * Central message listener. All communication between content scripts,
 * the preview page, and this background worker goes through here.
 */
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!message || typeof message.type !== "string") return false;

  switch (message.type) {
    case "OPEN_PREVIEW": {
      handleOpenPreview(message.payload, sender)
        .then((result) => sendResponse({ ok: true, result }))
        .catch((err) => sendResponse({ ok: false, error: String(err) }));
      return true; // keep the message channel open for async sendResponse
    }

    case "DOWNLOAD_FILE": {
      handleDownloadFile(message.payload)
        .then((downloadId) => sendResponse({ ok: true, downloadId }))
        .catch((err) => sendResponse({ ok: false, error: String(err) }));
      return true;
    }

    case "GET_ICON_URL": {
      sendResponse({ ok: true, url: chrome.runtime.getURL("icons/icon48.png") });
      return false;
    }

    default:
      return false;
  }
});

/**
 * Opens the preview tab for a given file URL.
 */
async function handleOpenPreview(payload, sender) {
  const { fileUrl, fileName, mimeType } = payload || {};

  if (!fileUrl || !isSupportedUrl(fileUrl)) {
    throw new Error("Unsupported or invalid file URL.");
  }

  const previewUrl = buildPreviewUrl({ fileUrl, fileName, mimeType });

  // Open the preview in a new tab, next to the tab that triggered it.
  const openerTab = sender && sender.tab ? sender.tab : null;
  const createProps = { url: previewUrl, active: true };
  if (openerTab && typeof openerTab.index === "number") {
    createProps.index = openerTab.index + 1;
  }
  if (openerTab && typeof openerTab.windowId === "number") {
    createProps.windowId = openerTab.windowId;
  }

  const tab = await chrome.tabs.create(createProps);
  return { tabId: tab.id };
}

/**
 * Triggers a real download via the chrome.downloads API.
 */
async function handleDownloadFile(payload) {
  const { fileUrl, fileName } = payload || {};

  if (!fileUrl || !isSupportedUrl(fileUrl)) {
    throw new Error("Unsupported or invalid file URL.");
  }

  await markUrlAsAllowed(fileUrl);

  const downloadOptions = { url: fileUrl, saveAs: false };
  if (fileName) downloadOptions.filename = sanitizeFilename(fileName);

  return new Promise((resolve, reject) => {
    chrome.downloads.download(downloadOptions, (downloadId) => {
      if (chrome.runtime.lastError) {
        reject(new Error(chrome.runtime.lastError.message));
      } else {
        resolve(downloadId);
      }
    });
  });
}

/**
 * Strips characters that are invalid in filenames on Windows
 * (\ / : * ? " < > |) since this extension targets Windows users.
 */
function sanitizeFilename(name) {
  return name.replace(/[\\/:*?"<>|]/g, "_").trim() || "download";
}

/**
 * Checks whether a URL was recently marked "allowed" via markUrlAsAllowed()
 * — meaning WE just initiated this exact download ourselves (the user
 * clicked "Download" in the preview UI). Used to avoid an infinite loop
 * where our own download gets caught by the safety net below and reopened
 * as a preview.
 */
async function isUrlRecentlyAllowed(url) {
  const data = await chrome.storage.session.get(ALLOW_LIST_KEY);
  const list = data[ALLOW_LIST_KEY] || {};
  const timestamp = list[url];
  if (!timestamp) return false;
  return Date.now() - timestamp < 5 * 60 * 1000;
}

/** Extracts a lowercase file extension from a filename or URL string. */
function extractExtension(value) {
  if (!value) return "";
  try {
    const clean = value.split(/[?#]/)[0];
    const match = clean.match(/\.([a-zA-Z0-9]{1,6})$/);
    return match ? match[1].toLowerCase() : "";
  } catch (err) {
    return "";
  }
}

// File types this safety net will redirect into the preview flow. Kept
// deliberately narrower than "every download" — we don't want to hijack
// things like right-click "Save Image As" on a photo, where the user's
// intent to just save the file (often to a chosen folder/name) is very
// explicit and a surprise preview tab would be unwelcome. Documents are
// the case this extension is built around, so those get the safety net.
const SAFETY_NET_EXTENSIONS = [
  "pdf", "doc", "docx", "xls", "xlsx", "ppt", "pptx",
  "txt", "csv", "rtf", "zip", "rar", "7z",
];
const SAFETY_NET_MIME_PATTERN =
  /pdf|msword|officedocument|ms-excel|ms-powerpoint|text\/plain|text\/csv|rtf|zip|x-rar|x-7z/i;

/**
 * SAFETY NET: our content script can only intercept normal <a href> clicks
 * it recognizes by URL pattern. Some sites trigger downloads in ways it
 * can't see coming — JS-driven downloads, redirect chains, or links whose
 * URL doesn't hint at the file type at all (e.g. `/file?id=123`). This
 * listener catches the download at the browser level, after Chrome's
 * download manager has already decided to save a file, regardless of how
 * that download was triggered, and — if it's a document type we handle —
 * cancels the native download and opens our preview instead.
 *
 * Note: if the user has "Ask where to save each file" enabled in Chrome,
 * the save dialog may already have appeared by this point; canceling
 * afterwards is still the best available option since Chrome's API
 * doesn't expose a way to intercept *before* that dialog.
 */
chrome.downloads.onCreated.addListener(async (item) => {
  try {
    if (!item || !item.url || !/^https?:/i.test(item.url)) return;

    // Don't re-intercept a download WE just started from the preview UI.
    if (await isUrlRecentlyAllowed(item.url)) return;

    const ext = extractExtension(item.filename) || extractExtension(item.url);
    const mimeMatches = item.mime && SAFETY_NET_MIME_PATTERN.test(item.mime);

    if (!SAFETY_NET_EXTENSIONS.includes(ext) && !mimeMatches) {
      return; // Not a type we preview (e.g. images, executables) — let it download as normal.
    }

    await chrome.downloads.cancel(item.id);
    chrome.downloads.erase({ id: item.id }).catch(() => {});

    const suggestedName = item.filename ? item.filename.split(/[\\/]/).pop() : undefined;
    const previewUrl = buildPreviewUrl({
      fileUrl: item.url,
      fileName: suggestedName,
      mimeType: item.mime || undefined,
    });

    await chrome.tabs.create({ url: previewUrl, active: true });
  } catch (err) {
    // Fail open: if anything goes wrong here, we simply don't touch the
    // download — the user still gets their file via Chrome's normal flow.
    console.warn("[mpouriew] Download safety-net skipped due to an error:", err);
  }
});

// Log installation for easier debugging via chrome://extensions service worker console.
chrome.runtime.onInstalled.addListener((details) => {
  console.log(`[mpouriew] Extension ${details.reason}. Version:`, chrome.runtime.getManifest().version);
});
